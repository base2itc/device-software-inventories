<#
.SYNOPSIS
    Führt grundlegende Client-Konfiguration durch (z. B. Updates, Energiesparmodus, Admin-User, PC-Name).

.ANWENDUNG
    1. Skript mit Admin-Rechten ausführen.
    2. Dann den Befehl aufrufen: Initialize-ClientSetup

.PARAMETER ComputerName
    Neuer Name, der für den Computer gesetzt werden soll.
#>

function Initialize-ClientSetup {
    [CmdletBinding()]
    param (
        [string]$ComputerName = "NeuerComputerName"
    )

    $ErrorActionPreference = "Stop"

    try {
        Write-Host "🔧 Starte Client-Initialisierung..." -ForegroundColor Cyan

        $pcType = (Get-WmiObject -Class Win32_ComputerSystem).PCSystemType
        Write-Host "⚡ Passe Energiesparplan an (PC-Typ: $pcType)..."
        if ($pcType -eq 1) {
            powercfg -change -standby-timeout-ac 0
        } elseif ($pcType -eq 2) {
            powercfg -change -standby-timeout-ac 0
            powercfg -change -standby-timeout-dc 30
        }

        Write-Host "🪟 Installiere Windows-Updates..."
        Install-Module -Name PSWindowsUpdate -Force -SkipPublisherCheck
        Import-Module PSWindowsUpdate
        Install-WindowsUpdate -AcceptAll -AutoReboot

        Write-Host "🖥️ Setze Rechnername auf '$ComputerName'..."
        Rename-Computer -NewName $ComputerName

        Write-Host "👤 Erstelle Admin-Benutzer..."
        $adminUsername = "AdminUser"
        $adminPassword = -join ((65..90) + (97..122) + (48..57) | Get-Random -Count 12 | ForEach-Object { [char]$_ })
        net user $adminUsername $adminPassword /add

        if (-not (Get-LocalGroup -Name "Administrators" -ErrorAction SilentlyContinue)) {
            net localgroup Administrators /add
        }
        net localgroup Administrators $adminUsername /add

        $credPath = "C:\AdminCredentials.txt"
        "Username: $adminUsername`nPassword: $adminPassword" | Out-File -FilePath $credPath
        Write-Host "🔐 Admin-Zugang gespeichert unter $credPath"

        Write-Host "✅ Client-Setup erfolgreich abgeschlossen!" -ForegroundColor Green
    }
    catch {
        Write-Error "❌ Fehler bei der Initialisierung: $($_.Exception.Message)"
    }
}
